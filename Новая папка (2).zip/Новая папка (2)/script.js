function updateCartDisplay() {
    const countElement = document.getElementById('cart-count');
    if (countElement) {
        const currentCount = localStorage.getItem('cartCount') || 0;
        countElement.innerText = currentCount;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    updateCartDisplay();

    const addButtons = document.querySelectorAll('.add-to-cart');
    addButtons.forEach(button => {
        button.addEventListener('click', () => {
            let currentCount = parseInt(localStorage.getItem('cartCount') || 0);
            currentCount++;
            localStorage.setItem('cartCount', currentCount);
            updateCartDisplay();
            alert('Товар добавлен в корзину!');
        });
    });
});